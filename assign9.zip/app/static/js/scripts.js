    let click_name = document.querySelector("#click_me") /*queryselector let you check the movement of click*/
    click_me.addEventListener("click", alert_click)
    
    function alert_click() {
    alert("You have clicked here!")
    } 
